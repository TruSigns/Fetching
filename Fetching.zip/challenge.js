function getRandomNumber() {
  return new Promise(function (resolve, reject) {
    setTimeout(function () {
      const randomNum = Math.random();
      const error = randomNum > 100 ? True : false;

      if (error) {
        reject(new error("Not Enough, stranger...."));
      } else {
        resolve(randomNum);
      }
    }, 5000);
  });
}

getRandomNumber()
    .then(function(value) {
        console.log("What you trying to buy, stranger?!", value)
    })
    .catch(function(notEnough){
        console.log(notEnough, "Not Enough cash, stranger....")
    })
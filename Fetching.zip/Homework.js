const fetch = require("node-fetch");

fetch("https://geocode.xyz/Raleigh?json=1")
  .then((response) => {
    console.log("data fetched", response);
    // handle response data
  })
  .catch((err) => {
    consolee.log("data not fetched", err);
    // handle errors
  });
